﻿using System;

namespace zadanie_3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
    interface Observer
    {
        void update();
    }
    public class Klient : Observer
    {
        public string nazwa;
        

        public void update()
        {
        }
    }
    interface Observable
    {
        public zarejestrujObserwatora(Observer o)
        {

        }

         void Notify()
        {

        }

    }
    
    public class Aukcja : Observable
    {
        int id;
        string opis;
        double cena;
        DateTime DataZakonczenia;

        public Aukcja()
        {
        }

        public void Notify()
        {
            throw new NotImplementedException();
        }

        public void zarejestrujObserwatora(IObserver o)
        {
            throw new NotImplementedException();
        }
    }
    abstract class Powiadomienie
    {
        public string GetOpis()
        {
            
        }
        
    }
    class PowiadomienieOpis : Powiadomienie
    {
        public PowiadomienieOpis()
        {
            
        }
    }
    class PowiadomienieCena : Powiadomienie
    {
        public PowiadomienieCena()
        {
           
        }
    }
    class PowiadomoenieDataZakonczenia : Powiadomienie
    {
        public PowiadomoenieDataZakonczenia()
        {
        }
    }

}
