﻿using System;
using System.Collections.Generic;

namespace zadanie_1
{
    class Program
    {
        private static List<Pojazd> pojazdy;

        static void Main(string[] args)
        {
            Pojazd p1 = new Osobowy(600, "Tico");
            Pojazd p2 = new Osobowy(900, "Toyota");
            Pojazd p3 = new Ciezarowka(2000, "Scania");
            Pojazd p4 = new Ciezarowka(2500, "Mercedes");
            Prom b1 = new Prom(4000,0,pojazdy,false);
            
            b1.ZaladujPojazd(p1);
            b1.ZaladujPojazd(p2);
            b1.ZaladujPojazd(p3);
            b1.ZaladujPojazd(p4);

        }
    }
    public abstract class Pojazd
    {
        public double Masa;
        public string Nazwa;

        protected Pojazd(double masa, string nazwa)
        {
            this.Masa = masa;
            this.Nazwa = nazwa;
        }
    }
    public class Ciezarowka : Pojazd
    {
        public Ciezarowka(double masa, string nazwa) : base(masa, nazwa)
        {
            this.Masa = masa;
            this.Nazwa = nazwa;
        }
    }
    public class Osobowy : Pojazd
    {
        public Osobowy(double masa, string nazwa) : base(masa, nazwa)
        {
            this.Masa = masa;
            this.Nazwa = nazwa;
        }
    }
    public class Prom
    {
        private double ladownosc;
        private double masaPojazdow;
        private List<Pojazd> pojazdy;
        private bool zaladowany;

        

        public Prom(double ladownosc, double masaPojazdow, List<Pojazd> pojazdy, bool zaladowany)
        {
            this.ladownosc = ladownosc;
            this.masaPojazdow = MasaZaladowanychPojazdow();
            this.pojazdy = new List<Pojazd>();
            this.zaladowany = zaladowany;
        }

        public double MasaZaladowanychPojazdow()
        {
            double i;
            i = 0;
            foreach(Pojazd a in pojazdy)
            {
                i = i + a.Masa;

            }
            return i;
        }
        public void WyladujPojazd(Pojazd p)
        {
            pojazdy.Remove(p);
        }
        public void ZaladujPojazd(Pojazd p)
        {
            try
            {
                if(masaPojazdow<ladownosc)
                    pojazdy.Add(p);
            }
            catch
            {
                throw new WyczerpanaLadownosc(); zaladowany = true;
            }
                


        }
    }
    public class WyczerpanaLadownosc :Exception
    {
        public WyczerpanaLadownosc()
        {
            Console.WriteLine("Ładownosc przekroczona");
        }
    }

}