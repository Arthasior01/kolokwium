﻿using System;
using System.Collections.Generic;

namespace zadanie_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
    public class Pracownik
    {
        public string imie;
        public string nazwisko;
        public int  pesel { get; set; }
        public double pensja { get; set; }
        public int wiek;

        public Pracownik(string imie, string nazwisko, int pesel, double pensja, int wiek)
        {
            this.imie = imie;
            this.nazwisko = nazwisko;
            this.pesel = pesel;
            this.pensja = pensja;
            this.wiek = wiek;
        }
    }
    public class Firma : Pracownik
    {
        List<Pracownik> pracownicy;

        public Firma(string imie, string nazwisko, int pesel, double pensja, int wiek) : base(imie, nazwisko, pesel, pensja, wiek)
        {
            this.imie = imie;
            this.nazwisko = nazwisko;
            this.pesel = pesel;
            this.pensja = pensja;
            this.wiek = wiek;
        }

        void PobierzPracownikowZPensjaMniejszaNiz(double p)
        {
            
            
            foreach(Pracownik i in pracownicy)
            {
                
                if(i.pensja<p)
                {


                }
            }
        }
    }
}
